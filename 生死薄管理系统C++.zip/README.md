# 生死簿后台管理系统

这是一个C++控制台应用程序，用于管理生死簿数据。

## 功能特性

- 添加人员记录
- 查看所有记录
- 查询在世者
- 查询已故者
- 修改死亡信息
- 删除记录

## 系统要求

### 必需软件
1. **Visual Studio 2022** (推荐) 或 Visual Studio 2019
2. **MySQL Server** 8.0 或更高版本
3. **MySQL Connector/C++ 8.0**

### 安装步骤

#### 1. 安装 MySQL Connector/C++
1. 下载 MySQL Connector/C++ 8.0
2. 安装到默认路径：`C:\Program Files\MySQL\Connector C++ 8.0\`

#### 2. 设置数据库
1. 启动 MySQL 服务
2. 使用 MySQL 客户端连接到数据库服务器
3. 执行 `fix_database.sql` 脚本创建数据库和表

```sql
mysql -h xts.dyfl.top -P 3307 -u root -p --default-character-set=utf8mb4 < fix_database.sql
```

或者运行批处理文件：
```bash
fix_database.bat
```

#### 3. 配置数据库连接
编辑 `config.h` 文件，确保数据库连接信息正确：

```cpp
const std::string DB_HOST = "tcp://xts.dyfl.top:3307";
const std::string DB_USER = "root";
const std::string DB_PASS = "你的密码";
const std::string DB_NAME = "underworld_db";
```

## 编译和运行

### 使用 Visual Studio
1. 打开 `lifeanddead.sln`
2. 选择 x64 平台和 Debug 配置
3. 按 F5 编译并运行

### 使用命令行
```bash
# 使用 MSBuild
"C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe" lifeanddead.sln /p:Configuration=Debug /p:Platform=x64

# 运行程序
.\x64\Debug\lifeanddead.exe
```

## 使用说明

启动程序后，会显示主菜单：

```
===== 生死簿后台管理系统 =====
1. 添加记录
2. 查看所有记录
3. 查询在世者
4. 查询已故者
5. 修改死亡信息
6. 删除记录
0. 退出系统
请输入选项（0-6）：
```

### 添加记录
- 输入姓名、性别、功德值、出生日期
- 选择是否已故，如果已故需要输入去世日期

### 查看记录
- 选项2：查看所有记录
- 选项3：只查看在世者
- 选项4：只查看已故者

### 修改死亡信息
- 输入要修改的人员ID
- 输入新的去世日期
- 系统会自动将状态改为"已故"

### 删除记录
- 输入要删除的人员ID
- 确认删除操作

## 数据库表结构

```sql
CREATE TABLE life_and_death (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    gender VARCHAR(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    virtue INT NOT NULL DEFAULT 0,
    birth_date DATE NOT NULL,
    death_date VARCHAR(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
    status VARCHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '在世',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## 故障排除

### 编译错误
1. 确保 MySQL Connector/C++ 已正确安装
2. 检查项目配置中的包含路径和库路径
3. 确保使用正确的平台（x64）

### 数据库连接错误
1. 检查 MySQL 服务是否运行
2. 验证数据库连接信息（主机、端口、用户名、密码）
3. 确保数据库和表已创建

### 中文乱码问题
如果遇到 `Incorrect string value: '\xCC\xE4\xCA\xB9' for column 'name'` 错误：

1. **重新创建数据库**：
   ```bash
   mysql -h xts.dyfl.top -P 3307 -u root -p --default-character-set=utf8mb4 < fix_database.sql
   ```

2. **检查数据库字符集**：
   ```sql
   SHOW CREATE DATABASE underworld_db;
   SHOW CREATE TABLE life_and_death;
   ```

3. **确保使用UTF-8字符集**：
   - 数据库：`utf8mb4`
   - 表：`utf8mb4_unicode_ci`
   - 连接：`utf8mb4`

### 运行时错误
1. 检查 MySQL Connector/C++ 的 DLL 文件是否在系统路径中
2. 确保数据库表结构正确
3. 确保字符集设置正确

## 注意事项

- 程序使用 UTF-8 编码，确保控制台支持中文显示
- 日期格式：YYYY-MM-DD
- 功德值为整数，范围建议 0-100
- 删除操作不可恢复，请谨慎操作
- 数据库使用 `utf8mb4` 字符集以支持完整的中文字符 