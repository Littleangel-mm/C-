#pragma once
#include <string>

const std::string DB_HOST = "tcp://127.0.0.1:3306";
const std::string DB_USER = "root";
const std::string DB_PASS = "fl3692458121"; // TODO: 改成你自己的
const std::string DB_NAME = "underworld_db";
