#include <iostream>
#include <string>
#include <vector>

// 简单的Person结构体用于测试
struct Person {
    int id;
    std::string name;
    std::string gender;
    int virtue;
    std::string birth_date;
    std::string death_date;
    std::string status;
    
    Person() : id(0), virtue(0) {}
};

// 简单的数据库管理器用于测试
class SimpleDB {
private:
    std::vector<Person> persons;
    int nextId;

public:
    SimpleDB() : nextId(1) {}
    
    bool connect() { 
        std::cout << "[简单数据库] 连接成功" << std::endl;
        return true; 
    }
    
    void disconnect() {
        std::cout << "[简单数据库] 已断开连接" << std::endl;
    }
    
    bool addPerson(const Person& p) {
        Person newPerson = p;
        newPerson.id = nextId++;
        persons.push_back(newPerson);
        std::cout << "[添加成功] " << newPerson.name << " (ID: " << newPerson.id << ")" << std::endl;
        return true;
    }
    
    std::vector<Person> getAll() {
        return persons;
    }
    
    std::vector<Person> getByStatus(const std::string& status) {
        std::vector<Person> result;
        for (const auto& p : persons) {
            if (p.status == status) {
                result.push_back(p);
            }
        }
        return result;
    }
    
    bool updateDeathInfo(int id, const std::string& death_date) {
        for (auto& p : persons) {
            if (p.id == id) {
                p.death_date = death_date;
                p.status = "已故";
                std::cout << "[更新成功] ID: " << id << std::endl;
                return true;
            }
        }
        std::cout << "[更新失败] 未找到ID: " << id << std::endl;
        return false;
    }
    
    bool deletePerson(int id) {
        for (auto it = persons.begin(); it != persons.end(); ++it) {
            if (it->id == id) {
                persons.erase(it);
                std::cout << "[删除成功] ID: " << id << std::endl;
                return true;
            }
        }
        std::cout << "[删除失败] 未找到ID: " << id << std::endl;
        return false;
    }
};

void printMenu() {
    std::cout << "\n===== 生死簿后台管理系统（简化测试版）=====\n"
        << "1. 添加记录\n"
        << "2. 查看所有记录\n"
        << "3. 查询在世者\n"
        << "4. 查询已故者\n"
        << "5. 修改死亡信息\n"
        << "6. 删除记录\n"
        << "0. 退出系统\n"
        << "请输入选项（0-6）：";
}

void printPerson(const Person& p) {
    std::cout << "[" << p.id << "] "
        << p.name << " | "
        << p.gender << " | "
        << p.virtue << "功德 | "
        << "生：" << p.birth_date
        << " 死：" << (p.death_date.empty() ? "—" : p.death_date)
        << " | 状态：" << p.status << "\n";
}

int main() {
    SimpleDB db;
    if (!db.connect()) return 1;

    int choice;
    while (true) {
        printMenu();
        std::cin >> choice;

        if (choice == 0) break;
        if (choice == 1) {
            Person p;
            std::cout << "姓名："; std::cin >> p.name;
            std::cout << "性别（男/女）："; std::cin >> p.gender;
            std::cout << "功德："; std::cin >> p.virtue;
            std::cout << "出生日期（yyyy-mm-dd）："; std::cin >> p.birth_date;
            std::cout << "是否已故？(0=在世,1=已故)："; int dead; std::cin >> dead;
            if (dead) {
                std::cout << "去世日期（yyyy-mm-dd）："; std::cin >> p.death_date;
                p.status = "已故";
            }
            else {
                p.status = "在世";
            }
            db.addPerson(p);
        }
        else if (choice == 2) {
            for (auto& p : db.getAll()) printPerson(p);
        }
        else if (choice == 3) {
            for (auto& p : db.getByStatus("在世")) printPerson(p);
        }
        else if (choice == 4) {
            for (auto& p : db.getByStatus("已故")) printPerson(p);
        }
        else if (choice == 5) {
            int id;
            std::string date;
            std::cout << "输入 ID："; std::cin >> id;
            std::cout << "去世日期（yyyy-mm-dd）："; std::cin >> date;
            db.updateDeathInfo(id, date);
        }
        else if (choice == 6) {
            int id;
            std::cout << "输入 ID 删除："; std::cin >> id;
            db.deletePerson(id);
        }
        else {
            std::cout << "无效选项，请重试。\n";
        }
    }

    db.disconnect();
    return 0;
} 