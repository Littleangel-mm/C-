#include "DatabaseManager.h"
#include "config.h"
#include <jdbc/mysql_driver.h>
#include <jdbc/mysql_connection.h>
#include <jdbc/cppconn/prepared_statement.h>
#include <jdbc/cppconn/resultset.h>
#include <iostream>
#include <stdexcept>

class DatabaseManager::Impl {
public:
    sql::mysql::MySQL_Driver* driver = nullptr;
    sql::Connection* conn = nullptr;
};

DatabaseManager::DatabaseManager() {
    impl = new Impl();
}

DatabaseManager::~DatabaseManager() {
    disconnect();
    delete impl;
}

bool DatabaseManager::connect() {
    try {
        impl->driver = sql::mysql::get_mysql_driver_instance();
        
        // 构建连接URL，包含完整的字符集设置
        std::string url = DB_HOST + "?useUnicode=true&characterEncoding=utf8mb4&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&charset=utf8mb4";
        impl->conn = impl->driver->connect(url, DB_USER, DB_PASS);
        
        // 设置数据库
        impl->conn->setSchema(DB_NAME);
        
        // 强制设置连接字符集为utf8mb4
        auto* stmt = impl->conn->createStatement();
        stmt->execute("SET NAMES utf8mb4");
        stmt->execute("SET CHARACTER SET utf8mb4");
        stmt->execute("SET character_set_client = utf8mb4");
        stmt->execute("SET character_set_connection = utf8mb4");
        stmt->execute("SET character_set_database = utf8mb4");
        stmt->execute("SET character_set_results = utf8mb4");
        stmt->execute("SET character_set_server = utf8mb4");
        stmt->execute("SET collation_connection = utf8mb4_unicode_ci");
        stmt->execute("SET collation_database = utf8mb4_unicode_ci");
        stmt->execute("SET collation_server = utf8mb4_unicode_ci");
        delete stmt;
        
        std::cout << "[数据库连接成功] 连接到: " << DB_HOST << "/" << DB_NAME << std::endl;
        return true;
    }
    catch (sql::SQLException& e) {
        std::cerr << "[数据库连接失败] " << e.what() << std::endl;
        impl->conn = nullptr; // 确保连接指针为空
        return false;
    }
    catch (const std::exception& e) {
        std::cerr << "[数据库连接异常] " << e.what() << std::endl;
        impl->conn = nullptr; // 确保连接指针为空
        return false;
    }
}

void DatabaseManager::disconnect() {
    if (impl->conn) {
        delete impl->conn;
        impl->conn = nullptr;
    }
}

bool DatabaseManager::addPerson(const Person& p) {
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement(
            "INSERT INTO life_and_death (name, gender, virtue, birth_date, death_date, status) VALUES (?, ?, ?, ?, ?, ?)");
        stmt->setString(1, p.name);
        stmt->setString(2, p.gender);
        stmt->setInt(3, p.virtue);
        stmt->setString(4, p.birth_date);
        stmt->setString(5, p.death_date);
        stmt->setString(6, p.status);
        stmt->execute();
        delete stmt;
        std::cout << "[添加成功] " << p.name << std::endl;
        return true;
    }
    catch (sql::SQLException& e) {
        std::cerr << "[添加失败] " << e.what() << std::endl;
        return false;
    }
}

std::vector<Person> DatabaseManager::getAll() {
    std::vector<Person> list;
    
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement("SELECT * FROM life_and_death ORDER BY id");
        auto* rs = stmt->executeQuery();
        while (rs->next()) {
            Person p;
            p.id = rs->getInt("id");
            p.name = rs->getString("name");
            p.gender = rs->getString("gender");
            p.virtue = rs->getInt("virtue");
            p.birth_date = rs->getString("birth_date");
            if (rs->isNull("death_date")) {
                p.death_date = "";
            } else {
                p.death_date = rs->getString("death_date");
            }
            p.status = rs->getString("status");
            list.push_back(p);
        }
        delete rs;
        delete stmt;
    }
    catch (sql::SQLException& e) {
        std::cerr << "[查询失败] " << e.what() << std::endl;
    }
    return list;
}

std::vector<Person> DatabaseManager::getByStatus(const std::string& status) {
    std::vector<Person> list;
    
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement("SELECT * FROM life_and_death WHERE status = ? ORDER BY id");
        stmt->setString(1, status);
        auto* rs = stmt->executeQuery();
        while (rs->next()) {
            Person p;
            p.id = rs->getInt("id");
            p.name = rs->getString("name");
            p.gender = rs->getString("gender");
            p.virtue = rs->getInt("virtue");
            p.birth_date = rs->getString("birth_date");
            if (rs->isNull("death_date")) {
                p.death_date = "";
            } else {
                p.death_date = rs->getString("death_date");
            }
            p.status = rs->getString("status");
            list.push_back(p);
        }
        delete rs;
        delete stmt;
    }
    catch (sql::SQLException& e) {
        std::cerr << "[查询失败] " << e.what() << std::endl;
    }
    return list;
}

std::vector<Person> DatabaseManager::getByName(const std::string& name) {
    std::vector<Person> list;
    
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement("SELECT * FROM life_and_death WHERE name LIKE ? ORDER BY id");
        std::string searchPattern = "%" + name + "%";
        stmt->setString(1, searchPattern);
        auto* rs = stmt->executeQuery();
        while (rs->next()) {
            Person p;
            p.id = rs->getInt("id");
            p.name = rs->getString("name");
            p.gender = rs->getString("gender");
            p.virtue = rs->getInt("virtue");
            p.birth_date = rs->getString("birth_date");
            if (rs->isNull("death_date")) {
                p.death_date = "";
            } else {
                p.death_date = rs->getString("death_date");
            }
            p.status = rs->getString("status");
            list.push_back(p);
        }
        delete rs;
        delete stmt;
    }
    catch (sql::SQLException& e) {
        std::cerr << "[按名字查询失败] " << e.what() << std::endl;
    }
    return list;
}

bool DatabaseManager::updateDeathInfo(int id, const std::string& death_date) {
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement(
            "UPDATE life_and_death SET death_date = ?, status = '已故' WHERE id = ?");
        stmt->setString(1, death_date);
        stmt->setInt(2, id);
        int affected = stmt->executeUpdate();
        delete stmt;
        if (affected > 0) {
            std::cout << "[更新成功] ID: " << id << std::endl;
            return true;
        } else {
            std::cout << "[更新失败] 未找到ID: " << id << std::endl;
            return false;
        }
    }
    catch (sql::SQLException& e) {
        std::cerr << "[更新失败] " << e.what() << std::endl;
        return false;
    }
}

bool DatabaseManager::deletePerson(int id) {
    if (!impl->conn) {
        throw std::runtime_error("数据库未连接");
    }
    
    try {
        auto* stmt = impl->conn->prepareStatement("DELETE FROM life_and_death WHERE id = ?");
        stmt->setInt(1, id);
        int affected = stmt->executeUpdate();
        delete stmt;
        if (affected > 0) {
            std::cout << "[删除成功] ID: " << id << std::endl;
            return true;
        } else {
            std::cout << "[删除失败] 未找到ID: " << id << std::endl;
            return false;
        }
    }
    catch (sql::SQLException& e) {
        std::cerr << "[删除失败] " << e.what() << std::endl;
        return false;
    }
}

bool DatabaseManager::updatePerson(const Person& p) {
    if (!impl->conn) throw std::runtime_error("数据库未连接");
    try {
        auto* stmt = impl->conn->prepareStatement(
            "UPDATE life_and_death SET name=?, gender=?, virtue=?, birth_date=?, death_date=?, status=? WHERE id=?");
        stmt->setString(1, p.name);
        stmt->setString(2, p.gender);
        stmt->setInt(3, p.virtue);
        stmt->setString(4, p.birth_date);
        stmt->setString(5, p.death_date);
        stmt->setString(6, p.status);
        stmt->setInt(7, p.id);
        int affected = stmt->executeUpdate();
        delete stmt;
        if (affected > 0) {
            std::cout << "[全字段更新成功] ID: " << p.id << std::endl;
            return true;
        } else {
            std::cout << "[全字段更新失败] 未找到ID: " << p.id << std::endl;
            return false;
        }
    } catch (sql::SQLException& e) {
        std::cerr << "[全字段更新失败] " << e.what() << std::endl;
        return false;
    }
}
