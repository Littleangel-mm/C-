# GUI乱码问题解决方案

## 问题描述
您的生死簿管理系统GUI界面显示中文乱码，主要原因是字符编码转换问题。

## 已修复的问题

### 1. 字符串转换函数改进
- 改进了 `StringToWString` 函数，支持UTF-8和ANSI编码的自动检测
- 添加了 `WStringToString` 函数用于反向转换
- 增加了错误处理和回退机制

### 2. ListView字体设置优化
- 使用 `Microsoft YaHei UI` 字体，支持更好的中文显示
- 添加了字体回退机制，如果微软雅黑不可用则使用Tahoma
- 设置了ListView的扩展样式，提供更好的视觉效果

### 3. 数据库字符集设置
- 将数据库连接字符集从 `utf8` 改为 `utf8mb4`
- 添加了更完整的字符集设置命令
- 确保数据库连接使用正确的编码

### 4. 对话框字符串处理
- 改进了对话框中的字符串转换
- 使用新的 `WStringToString` 函数处理用户输入

## 解决步骤

### 步骤1：检查数据库字符集
确保您的MySQL数据库使用utf8mb4字符集：

```sql
-- 检查数据库字符集
SHOW VARIABLES LIKE 'character_set%';
SHOW VARIABLES LIKE 'collation%';

-- 如果需要，设置数据库字符集
ALTER DATABASE underworld_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 步骤2：重新编译项目
1. 打开Visual Studio
2. 清理解决方案 (Build -> Clean Solution)
3. 重新生成解决方案 (Build -> Rebuild Solution)

### 步骤3：运行修复脚本
双击运行 `fix_gui_charset.bat` 文件，它会：
- 设置系统代码页为UTF-8
- 重新编译项目
- 启动程序

### 步骤4：测试字符集转换
运行 `test_charset.bat` 来测试字符串转换是否正确工作。

## 常见问题排查

### 问题1：仍然显示乱码
**解决方案：**
1. 检查数据库中的实际数据编码
2. 确保数据库表使用utf8mb4字符集
3. 检查系统是否安装了中文字体

### 问题2：某些字符显示不正确
**解决方案：**
1. 检查源文件是否保存为UTF-8编码
2. 确保Visual Studio项目设置为Unicode字符集
3. 检查数据库连接字符串中的字符集设置

### 问题3：ListView显示问题
**解决方案：**
1. 确保系统安装了微软雅黑字体
2. 检查ListView的字体设置
3. 尝试使用不同的字体

## 技术细节

### 字符编码转换流程
1. 数据库数据 (UTF-8) → std::string
2. std::string → std::wstring (使用MultiByteToWideChar)
3. std::wstring → Windows控件显示

### 关键函数说明
- `StringToWString`: 将UTF-8字符串转换为宽字符串
- `WStringToString`: 将宽字符串转换为UTF-8字符串
- `MultiByteToWideChar`: Windows API字符转换函数

### 数据库连接参数
```
useUnicode=true&characterEncoding=utf8mb4&charset=utf8mb4
```

## 验证修复效果

1. 启动程序后，检查界面标题是否显示正确的中文
2. 查看ListView中的中文数据是否正确显示
3. 测试添加/编辑功能中的中文输入
4. 检查数据库中的中文数据是否正确保存

如果问题仍然存在，请检查：
- 数据库服务器的字符集设置
- 操作系统的区域设置
- Visual Studio的编码设置 