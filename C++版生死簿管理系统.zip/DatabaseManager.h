#pragma once
#include <string>
#include <vector>
#include <stdexcept>

// Person 结构体定义
struct Person {
    int id;
    std::string name;
    std::string gender;
    int virtue;
    std::string birth_date;
    std::string death_date;
    std::string status;
    
    Person() : id(0), virtue(0) {}
    Person(int i, const std::string& n, const std::string& g, int v, 
           const std::string& bd, const std::string& dd, const std::string& s)
        : id(i), name(n), gender(g), virtue(v), birth_date(bd), death_date(dd), status(s) {}
};

// 前向声明
namespace sql {
    class Connection;
    class PreparedStatement;
    class ResultSet;
    class SQLException;
    class SQLString;
}

class DatabaseManager {
private:
    class Impl;
    Impl* impl;

public:
    DatabaseManager();
    ~DatabaseManager();
    
    bool connect();
    void disconnect();
    bool addPerson(const Person& p);
    std::vector<Person> getAll();
    std::vector<Person> getByStatus(const std::string& status);
    std::vector<Person> getByName(const std::string& name);
    bool updateDeathInfo(int id, const std::string& death_date);
    bool deletePerson(int id);
    bool updatePerson(const Person& p);
};
