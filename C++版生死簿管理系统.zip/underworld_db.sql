#include <iostream>
#include "DatabaseManager.h"
#include <windows.h>
#include <commctrl.h>
#include <vector>
#include <string>
#pragma comment(lib, "comctl32.lib")

#define BTN_ALL     1001
#define BTN_QUERY   1002
#define BTN_ADD     1003
#define BTN_REFRESH 1004
#define BTN_EDIT    1005
#define BTN_DELETE  1006
#define IDC_LIST    2001

// 分页控件ID
#define BTN_PREV    2002
#define BTN_NEXT    2003
#define IDC_PAGE_INFO 2004

// 对话框控件ID
#define IDC_EDIT_NAME        3001
#define IDC_COMBO_GENDER     3002
#define IDC_EDIT_VIRTUE      3003
#define IDC_EDIT_BIRTH       3004
#define IDC_RADIO_ALIVE      3005
#define IDC_RADIO_DEAD       3006
#define IDC_EDIT_DEATH       3007
#define IDC_BTN_OK           3008
#define IDC_BTN_CANCEL       3009

enum FilterType { FILTER_ALL, FILTER_ALIVE, FILTER_DEAD };

// 分页信息结构
struct PageInfo {
    int currentPage;
    int pageSize;
    int totalItems;
    int totalPages;
    
    PageInfo() : currentPage(1), pageSize(20), totalItems(0), totalPages(0) {}
    
    void calculatePages() {
        totalPages = (totalItems + pageSize - 1) / pageSize;
        if (currentPage > totalPages && totalPages > 0) {
            currentPage = totalPages;
        }
        if (currentPage < 1) currentPage = 1;
    }
    
    int getStartIndex() const {
        return (currentPage - 1) * pageSize;
    }
    
    int getEndIndex() const {
        return min(getStartIndex() + pageSize, totalItems);
    }
};

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void InitListView(HWND hwndList);
void LoadListViewData(HWND hwndList, const std::vector<Person>& data);
void RefreshList(HWND hwndList);
INT_PTR CALLBACK AddEditDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void ShowAddEditDialog(HWND hParent, Person* pPerson = nullptr);
std::wstring StringToWString(const std::string& str);
std::string WStringToString(const std::wstring& wstr);

// 新增函数声明
void UpdatePageInfo(HWND hwnd);
void LoadCurrentPage(HWND hwndList);
void UpdatePageControls(HWND hwnd);
void CreateAddEditWindow(HWND hParent, Person* pPerson = nullptr);
LRESULT CALLBACK AddEditWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

DatabaseManager db;
FilterType currentFilter = FILTER_ALL;
int selectedId = -1;
HINSTANCE g_hInstance;
PageInfo pageInfo;
std::vector<Person> allData; // 存储所有数据用于分页

// 字符串转换函数 - 改进版本
std::wstring StringToWString(const std::string& str) {
    if (str.empty()) return L"";
    
    // 首先尝试UTF-8转换
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), (int)str.size(), NULL, 0);
    if (size_needed > 0) {
        std::wstring wstrTo(size_needed, 0);
        if (MultiByteToWideChar(CP_UTF8, 0, str.c_str(), (int)str.size(), &wstrTo[0], size_needed) > 0) {
            return wstrTo;
        }
    }
    
    // 如果UTF-8转换失败，尝试GBK转换
    size_needed = MultiByteToWideChar(CP_ACP, 0, str.c_str(), (int)str.size(), NULL, 0);
    if (size_needed > 0) {
        std::wstring wstrTo(size_needed, 0);
        if (MultiByteToWideChar(CP_ACP, 0, str.c_str(), (int)str.size(), &wstrTo[0], size_needed) > 0) {
            return wstrTo;
        }
    }
    
    // 如果都失败，返回原始字符串的简单转换
    return std::wstring(str.begin(), str.end());
}

// 添加WStringToString函数用于反向转换
std::string WStringToString(const std::wstring& wstr) {
    if (wstr.empty()) return "";
    
    int size_needed = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.size(), NULL, 0, NULL, NULL);
    if (size_needed > 0) {
        std::string strTo(size_needed, 0);
        if (WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.size(), &strTo[0], size_needed, NULL, NULL) > 0) {
            return strTo;
        }
    }
    
    // 如果UTF-8转换失败，尝试ANSI转换
    size_needed = WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), (int)wstr.size(), NULL, 0, NULL, NULL);
    if (size_needed > 0) {
        std::string strTo(size_needed, 0);
        if (WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), (int)wstr.size(), &strTo[0], size_needed, NULL, NULL) > 0) {
            return strTo;
        }
    }
    
    return std::string(wstr.begin(), wstr.end());
}

void printMenu() {
    std::cout << "\n===== 生死簿后台管理系统 =====\n"
        << "1. 添加记录\n"
        << "2. 查看所有记录\n"
        << "3. 查询在世者\n"
        << "4. 查询已故者\n"
        << "5. 修改死亡信息\n"
        << "6. 删除记录\n"
        << "0. 退出系统\n"
        << "请输入选项（0-6）：";
}

void printPerson(const Person& p) {
    std::cout << "[" << p.id << "] "
        << p.name << " | "
        << p.gender << " | "
        << p.virtue << "功德 | "
        << "生：" << p.birth_date
        << " 死：" << (p.death_date.empty() ? "—" : p.death_date)
        << " | 状态：" << p.status << "\n";
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    g_hInstance = hInstance;
    
    // 初始化通用控件
    INITCOMMONCONTROLSEX icex = { sizeof(icex), ICC_LISTVIEW_CLASSES };
    if (!InitCommonControlsEx(&icex)) {
        MessageBox(NULL, L"初始化通用控件失败！", L"错误", MB_ICONERROR);
        return -1;
    }

    // 注册窗口类
    const wchar_t CLASS_NAME[] = L"LifeAndDeathMainWindow";
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    
    if (!RegisterClass(&wc)) {
        MessageBox(NULL, L"注册窗口类失败！", L"错误", MB_ICONERROR);
        return -1;
    }

    // 创建主窗口
    HWND hwnd = CreateWindowEx(0, CLASS_NAME, L"生死簿后台管理系统",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1100, 700,
        NULL, NULL, hInstance, NULL);
    if (!hwnd) {
        MessageBox(NULL, L"创建主窗口失败！", L"错误", MB_ICONERROR);
        return -1;
    }
    
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // 消息循环
    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static HWND hBtnAll, hBtnQuery, hBtnAdd, hBtnRefresh;
    static HWND hList;
    static HWND hBtnEdit, hBtnDelete;
    static bool dbConnected = false;
    
    switch (uMsg) {
    case WM_CREATE: {
        try {
            // 尝试连接数据库
            if (!db.connect()) {
                MessageBox(hwnd, L"数据库连接失败！\n请检查：\n1. MySQL服务是否运行\n2. 数据库配置是否正确\n3. 网络连接是否正常", 
                          L"数据库连接错误", MB_ICONERROR);
                // 不退出程序，允许用户继续使用（可能只是数据库问题）
            } else {
                dbConnected = true;
            }
        } catch (const std::exception& e) {
            std::string errorMsg = "数据库连接异常: " + std::string(e.what());
            std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
            MessageBox(hwnd, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
        } catch (...) {
            MessageBox(hwnd, L"数据库连接发生未知异常！", L"异常错误", MB_ICONERROR);
        }
        
        // 创建顶部工具栏（严格按图顺序和文字）
        hBtnAll = CreateWindowW(L"BUTTON", L"全部", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 20, 20, 80, 35, hwnd, (HMENU)BTN_ALL, NULL, NULL);
        hBtnQuery = CreateWindowW(L"BUTTON", L"查询", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 110, 20, 80, 35, hwnd, (HMENU)BTN_QUERY, NULL, NULL);
        hBtnAdd = CreateWindowW(L"BUTTON", L"添加", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 200, 20, 80, 35, hwnd, (HMENU)BTN_ADD, NULL, NULL);
        hBtnRefresh = CreateWindowW(L"BUTTON", L"刷新", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 290, 20, 80, 35, hwnd, (HMENU)BTN_REFRESH, NULL, NULL);
        
        // ListView表格
        hList = CreateWindowW(WC_LISTVIEWW, L"", WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | WS_BORDER,
            20, 70, 760, 380, hwnd, (HMENU)IDC_LIST, NULL, NULL);
        if (!hList) {
            MessageBox(hwnd, L"创建ListView失败！", L"错误", MB_ICONERROR);
            return -1;
        }
        InitListView(hList);
        
        // 分页控件
        CreateWindowW(L"BUTTON", L"上一页", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 20, 470, 80, 30, hwnd, (HMENU)BTN_PREV, NULL, NULL);
        CreateWindowW(L"BUTTON", L"下一页", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 110, 470, 80, 30, hwnd, (HMENU)BTN_NEXT, NULL, NULL);
        CreateWindowW(L"STATIC", L"第1页/共1页 (共0条记录)", WS_CHILD | WS_VISIBLE | SS_CENTER, 200, 470, 300, 30, hwnd, (HMENU)IDC_PAGE_INFO, NULL, NULL);
        
        // 底部操作按钮
        hBtnEdit = CreateWindowW(L"BUTTON", L"修改", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 600, 470, 80, 30, hwnd, (HMENU)BTN_EDIT, NULL, NULL);
        hBtnDelete = CreateWindowW(L"BUTTON", L"删除", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 700, 470, 80, 30, hwnd, (HMENU)BTN_DELETE, NULL, NULL);
        
        // 如果数据库连接成功，加载数据
        if (dbConnected) {
            RefreshList(hList);
        } else {
            // 显示连接失败提示
            ListView_DeleteAllItems(hList);
            LVITEM lvi = { 0 };
            lvi.mask = LVIF_TEXT;
            lvi.iItem = 0;
            lvi.pszText = (LPWSTR)L"数据库连接失败，请检查配置";
            ListView_InsertItem(hList, &lvi);
        }
        break;
    }
    case WM_SIZE: {
        int width = LOWORD(lParam), height = HIWORD(lParam);
        int topBtnHeight = 35;
        int topBtnY = 20;
        int topBtnBottom = topBtnY + topBtnHeight + 20; // 20为按钮下间距
        int bottomBtnHeight = 30;
        int bottomBtnY = height - 60;
        int listViewY = topBtnBottom;
        int listViewHeight = bottomBtnY - listViewY - 10; // 10为底部分隔

        // 调整ListView大小（尽量填满）
        MoveWindow(hList, 20, listViewY, width - 40, listViewHeight, TRUE);

        // 调整分页控件位置
        MoveWindow(GetDlgItem(hwnd, BTN_PREV), 20, bottomBtnY, 80, bottomBtnHeight, TRUE);
        MoveWindow(GetDlgItem(hwnd, BTN_NEXT), 110, bottomBtnY, 80, bottomBtnHeight, TRUE);
        MoveWindow(GetDlgItem(hwnd, IDC_PAGE_INFO), 200, bottomBtnY, 300, bottomBtnHeight, TRUE);

        // 调整底部按钮位置
        MoveWindow(hBtnEdit, width - 200, bottomBtnY, 80, bottomBtnHeight, TRUE);
        MoveWindow(hBtnDelete, width - 100, bottomBtnY, 80, bottomBtnHeight, TRUE);
        break;
    }
    case WM_COMMAND: {
        if (!dbConnected) {
            MessageBox(hwnd, L"数据库未连接，无法执行操作！", L"提示", MB_ICONWARNING);
            return 0;
        }
        
        switch (LOWORD(wParam)) {
        case BTN_ALL:
            currentFilter = FILTER_ALL;
            pageInfo.currentPage = 1;
            RefreshList(hList);
            break;
        case BTN_QUERY:
            // 查询功能暂时与全部一致（可后续扩展为弹窗）
            currentFilter = FILTER_ALL;
            pageInfo.currentPage = 1;
            RefreshList(hList);
            break;
        case BTN_REFRESH:
            RefreshList(hList);
            break;
        case BTN_ADD:
            CreateAddEditWindow(hwnd);
            break;
        case BTN_EDIT:
            if (selectedId != -1) {
                try {
                    // 查找选中的人员数据
                    Person* selectedPerson = nullptr;
                    for (auto& p : allData) {
                        if (p.id == selectedId) {
                            selectedPerson = &p;
                            break;
                        }
                    }
                    if (selectedPerson) {
                        CreateAddEditWindow(hwnd, selectedPerson);
                    }
                } catch (const std::exception& e) {
                    std::string errorMsg = "查询数据异常: " + std::string(e.what());
                    std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
                    MessageBox(hwnd, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
                }
            } else {
                MessageBox(hwnd, L"请先选择一条记录！", L"提示", MB_ICONINFORMATION);
            }
            break;
        case BTN_DELETE:
            if (selectedId != -1) {
                if (MessageBox(hwnd, L"确定要删除选中记录吗？", L"确认删除", MB_YESNO | MB_ICONQUESTION) == IDYES) {
                    try {
                        db.deletePerson(selectedId);
                        RefreshList(hList);
                    } catch (const std::exception& e) {
                        std::string errorMsg = "删除数据异常: " + std::string(e.what());
                        std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
                        MessageBox(hwnd, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
                    }
                }
            } else {
                MessageBox(hwnd, L"请先选择一条记录！", L"提示", MB_ICONINFORMATION);
            }
            break;
        case BTN_PREV:
            if (pageInfo.currentPage > 1) {
                pageInfo.currentPage--;
                LoadCurrentPage(hList);
                UpdatePageControls(hwnd);
            }
            break;
        case BTN_NEXT:
            if (pageInfo.currentPage < pageInfo.totalPages) {
                pageInfo.currentPage++;
                LoadCurrentPage(hList);
                UpdatePageControls(hwnd);
            }
            break;
        }
        break;
    }
    case WM_NOTIFY: {
        LPNMHDR pnmh = (LPNMHDR)lParam;
        if (pnmh->idFrom == IDC_LIST) {
            switch (pnmh->code) {
            case LVN_ITEMCHANGED: {
                NMLISTVIEW* pnmv = (NMLISTVIEW*)lParam;
                if (pnmv->uNewState & LVIS_SELECTED) {
                    wchar_t buf[16] = {0};
                    ListView_GetItemText(hList, pnmv->iItem, 0, buf, 16);
                    selectedId = _wtoi(buf);
                }
                break;
            }
            }
        }
        break;
    }
    case WM_DESTROY:
        if (dbConnected) {
            db.disconnect();
        }
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

void InitListView(HWND hwndList) {
    LVCOLUMN lvc = { 0 };
    lvc.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
    const wchar_t* headers[] = { L"ID", L"姓名", L"性别", L"功德", L"出生日期", L"死亡日期", L"状态" };
    int widths[] = { 50, 100, 60, 60, 120, 120, 80 };
    for (int i = 0; i < 7; ++i) {
        lvc.pszText = (LPWSTR)headers[i];
        lvc.cx = widths[i];
        lvc.iSubItem = i;
        ListView_InsertColumn(hwndList, i, &lvc);
    }
    
    // 设置支持中文的字体（使用系统默认字体）
    HFONT hFont = CreateFontW(
        16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        FF_SWISS, L"Microsoft YaHei UI"
    );
    if (!hFont) {
        // 如果微软雅黑不可用，使用系统默认字体
        hFont = CreateFontW(
            16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            FF_SWISS, L"Tahoma"
        );
    }
    SendMessage(hwndList, WM_SETFONT, (WPARAM)hFont, TRUE);
    
    // 设置ListView的扩展样式，支持更好的显示
    ListView_SetExtendedListViewStyle(hwndList, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void LoadListViewData(HWND hwndList, const std::vector<Person>& data) {
    ListView_DeleteAllItems(hwndList);
    
    for (size_t i = 0; i < data.size(); ++i) {
        LVITEM lvi = { 0 };
        lvi.mask = LVIF_TEXT;
        lvi.iItem = (int)i;
        
        // ID列
        wchar_t buf[32];
        _itow_s(data[i].id, buf, 10);
        lvi.pszText = buf;
        ListView_InsertItem(hwndList, &lvi);
        
        // 其他列使用改进的字符串转换
        std::wstring wname = StringToWString(data[i].name);
        std::wstring wgender = StringToWString(data[i].gender);
        std::wstring wbirth = StringToWString(data[i].birth_date);
        std::wstring wdeath = StringToWString(data[i].death_date);
        std::wstring wstatus = StringToWString(data[i].status);
        
        // 设置各列文本
        ListView_SetItemText(hwndList, (int)i, 1, (LPWSTR)wname.c_str());
        ListView_SetItemText(hwndList, (int)i, 2, (LPWSTR)wgender.c_str());
        
        _itow_s(data[i].virtue, buf, 10);
        ListView_SetItemText(hwndList, (int)i, 3, buf);
        
        ListView_SetItemText(hwndList, (int)i, 4, (LPWSTR)wbirth.c_str());
        ListView_SetItemText(hwndList, (int)i, 5, (LPWSTR)wdeath.c_str());
        ListView_SetItemText(hwndList, (int)i, 6, (LPWSTR)wstatus.c_str());
    }
}

void RefreshList(HWND hwndList) {
    try {
        // 根据过滤条件获取数据
        if (currentFilter == FILTER_ALL) {
            allData = db.getAll();
        } else if (currentFilter == FILTER_ALIVE) {
            allData = db.getByStatus("在世");
        } else if (currentFilter == FILTER_DEAD) {
            allData = db.getByStatus("已故");
        }
        
        // 更新分页信息
        pageInfo.totalItems = (int)allData.size();
        pageInfo.calculatePages();
        
        // 加载当前页数据
        LoadCurrentPage(hwndList);
        
        // 更新分页控件状态
        UpdatePageControls(GetParent(hwndList));
        
        selectedId = -1;
    } catch (const std::exception& e) {
        std::string errorMsg = "刷新数据异常: " + std::string(e.what());
        std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
        MessageBox(NULL, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
        
        // 清空列表并显示错误信息
        ListView_DeleteAllItems(hwndList);
        LVITEM lvi = { 0 };
        lvi.mask = LVIF_TEXT;
        lvi.iItem = 0;
        lvi.pszText = (LPWSTR)L"数据加载失败";
        ListView_InsertItem(hwndList, &lvi);
    }
}

void ShowAddEditDialog(HWND hParent, Person* pPerson) {
    // 创建模态对话框窗口
    HWND hDlg = CreateWindowEx(
        WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
        L"#32770",  // 对话框类名
        pPerson ? L"修改人员信息" : L"添加人员信息",
        WS_POPUP | WS_CAPTION | WS_SYSMENU | DS_MODALFRAME | DS_CENTER,
        0, 0, 400, 350,
        hParent, NULL, g_hInstance, NULL
    );

    if (!hDlg) return;

    // 居中显示对话框
    RECT rcParent, rcDlg;
    GetWindowRect(hParent, &rcParent);
    GetWindowRect(hDlg, &rcDlg);
    int x = (rcParent.left + rcParent.right) / 2 - (rcDlg.right - rcDlg.left) / 2;
    int y = (rcParent.top + rcParent.bottom) / 2 - (rcDlg.bottom - rcDlg.top) / 2;
    SetWindowPos(hDlg, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

    // 创建控件
    CreateWindowW(L"STATIC", L"姓名:", WS_CHILD | WS_VISIBLE, 30, 30, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hEditName = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 100, 30, 200, 20, hDlg, (HMENU)IDC_EDIT_NAME, g_hInstance, NULL);

    CreateWindowW(L"STATIC", L"性别:", WS_CHILD | WS_VISIBLE, 30, 60, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hComboGender = CreateWindowW(L"COMBOBOX", L"", WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST, 100, 60, 200, 100, hDlg, (HMENU)IDC_COMBO_GENDER, g_hInstance, NULL);
    SendMessage(hComboGender, CB_ADDSTRING, 0, (LPARAM)L"男");
    SendMessage(hComboGender, CB_ADDSTRING, 0, (LPARAM)L"女");

    CreateWindowW(L"STATIC", L"功德:", WS_CHILD | WS_VISIBLE, 30, 90, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hEditVirtue = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 100, 90, 200, 20, hDlg, (HMENU)IDC_EDIT_VIRTUE, g_hInstance, NULL);

    CreateWindowW(L"STATIC", L"出生日期:", WS_CHILD | WS_VISIBLE, 30, 120, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hEditBirth = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 100, 120, 200, 20, hDlg, (HMENU)IDC_EDIT_BIRTH, g_hInstance, NULL);

    CreateWindowW(L"STATIC", L"状态:", WS_CHILD | WS_VISIBLE, 30, 150, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hRadioAlive = CreateWindowW(L"BUTTON", L"在世", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 100, 150, 60, 20, hDlg, (HMENU)IDC_RADIO_ALIVE, g_hInstance, NULL);
    HWND hRadioDead = CreateWindowW(L"BUTTON", L"已故", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 170, 150, 60, 20, hDlg, (HMENU)IDC_RADIO_DEAD, g_hInstance, NULL);

    CreateWindowW(L"STATIC", L"死亡日期:", WS_CHILD | WS_VISIBLE, 30, 180, 60, 20, hDlg, NULL, g_hInstance, NULL);
    HWND hEditDeath = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 100, 180, 200, 20, hDlg, (HMENU)IDC_EDIT_DEATH, g_hInstance, NULL);

    HWND hBtnOk = CreateWindowW(L"BUTTON", L"确定", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 200, 250, 80, 30, hDlg, (HMENU)IDC_BTN_OK, g_hInstance, NULL);
    HWND hBtnCancel = CreateWindowW(L"BUTTON", L"取消", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 300, 250, 80, 30, hDlg, (HMENU)IDC_BTN_CANCEL, g_hInstance, NULL);

    // 如果是修改模式，填充现有数据
    if (pPerson) {
        SetWindowTextW(hEditName, StringToWString(pPerson->name).c_str());
        if (pPerson->gender == "男") SendMessage(hComboGender, CB_SETCURSEL, 0, 0);
        else if (pPerson->gender == "女") SendMessage(hComboGender, CB_SETCURSEL, 1, 0);
        
        wchar_t buf[32];
        _itow_s(pPerson->virtue, buf, 10);
        SetWindowTextW(hEditVirtue, buf);
        SetWindowTextW(hEditBirth, StringToWString(pPerson->birth_date).c_str());
        
        if (pPerson->status == "在世") {
            SendMessage(hRadioAlive, BM_SETCHECK, BST_CHECKED, 0);
            EnableWindow(hEditDeath, FALSE);
        } else {
            SendMessage(hRadioDead, BM_SETCHECK, BST_CHECKED, 0);
            SetWindowTextW(hEditDeath, StringToWString(pPerson->death_date).c_str());
        }
    } else {
        // 添加模式，设置默认值
        SendMessage(hComboGender, CB_SETCURSEL, 0, 0);
        SendMessage(hRadioAlive, BM_SETCHECK, BST_CHECKED, 0);
        EnableWindow(hEditDeath, FALSE);
    }

    // 设置对话框过程
    SetWindowLongPtr(hDlg, GWLP_WNDPROC, (LONG_PTR)AddEditDlgProc);
    SetWindowLongPtr(hDlg, GWLP_USERDATA, (LONG_PTR)pPerson);

    // 显示对话框
    ShowWindow(hDlg, SW_SHOW);
    SetFocus(hEditName);

    // 消息循环
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (!IsWindow(hDlg) || !IsDialogMessage(hDlg, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        if (!IsWindow(hDlg)) break;
    }
}

INT_PTR CALLBACK AddEditDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    static HWND hEditName, hComboGender, hEditVirtue, hEditBirth, hRadioAlive, hRadioDead, hEditDeath;
    
    switch (message) {
    case WM_INITDIALOG:
        return TRUE;

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_RADIO_ALIVE:
            EnableWindow(GetDlgItem(hDlg, IDC_EDIT_DEATH), FALSE);
            SetWindowTextW(GetDlgItem(hDlg, IDC_EDIT_DEATH), L"");
            break;
        case IDC_RADIO_DEAD:
            EnableWindow(GetDlgItem(hDlg, IDC_EDIT_DEATH), TRUE);
            break;
        case IDC_BTN_OK: {
            try {
                // 收集数据
                wchar_t name[256], birth[256], death[256], virtue[32];
                GetWindowTextW(GetDlgItem(hDlg, IDC_EDIT_NAME), name, 256);
                GetWindowTextW(GetDlgItem(hDlg, IDC_EDIT_BIRTH), birth, 256);
                GetWindowTextW(GetDlgItem(hDlg, IDC_EDIT_DEATH), death, 256);
                GetWindowTextW(GetDlgItem(hDlg, IDC_EDIT_VIRTUE), virtue, 32);
                
                // 获取性别
                HWND hCombo = GetDlgItem(hDlg, IDC_COMBO_GENDER);
                int genderIndex = SendMessage(hCombo, CB_GETCURSEL, 0, 0);
                const wchar_t* gender = (genderIndex == 0) ? L"男" : L"女";
                
                // 获取状态
                bool isAlive = (SendMessage(GetDlgItem(hDlg, IDC_RADIO_ALIVE), BM_GETCHECK, 0, 0) == BST_CHECKED);
                const wchar_t* status = isAlive ? L"在世" : L"已故";
                
                // 验证数据
                if (wcslen(name) == 0 || wcslen(birth) == 0 || wcslen(virtue) == 0) {
                    MessageBox(hDlg, L"请填写完整信息！", L"提示", MB_ICONWARNING);
                    return TRUE;
                }
                
                // 创建Person对象
                Person p;
                p.name = WStringToString(name);
                p.gender = WStringToString(gender);
                p.virtue = _wtoi(virtue);
                p.birth_date = WStringToString(birth);
                p.death_date = WStringToString(death);
                p.status = WStringToString(status);
                
                // 获取原始数据（用于修改模式）
                Person* originalPerson = (Person*)GetWindowLongPtr(hDlg, GWLP_USERDATA);
                
                if (originalPerson) {
                    // 修改模式：更新死亡信息
                    if (!isAlive && wcslen(death) > 0) {
                        db.updateDeathInfo(originalPerson->id, p.death_date);
                    }
                } else {
                    // 添加模式
                    db.addPerson(p);
                }
                
                DestroyWindow(hDlg);
            } catch (const std::exception& e) {
                std::string errorMsg = "保存数据异常: " + std::string(e.what());
                std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
                MessageBox(hDlg, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
            }
            break;
        }
        case IDC_BTN_CANCEL:
            DestroyWindow(hDlg);
            break;
        }
        break;
        
    case WM_CLOSE:
        DestroyWindow(hDlg);
        break;
        
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return FALSE;
}

// 分页相关函数实现
void UpdatePageInfo(HWND hwnd) {
    wchar_t pageText[256];
    swprintf_s(pageText, L"第%d页/共%d页 (共%d条记录)", 
               pageInfo.currentPage, pageInfo.totalPages, pageInfo.totalItems);
    SetWindowTextW(GetDlgItem(hwnd, IDC_PAGE_INFO), pageText);
}

void LoadCurrentPage(HWND hwndList) {
    ListView_DeleteAllItems(hwndList);
    
    int startIndex = pageInfo.getStartIndex();
    int endIndex = pageInfo.getEndIndex();
    
    for (int i = startIndex; i < endIndex; ++i) {
        LVITEM lvi = { 0 };
        lvi.mask = LVIF_TEXT;
        lvi.iItem = i - startIndex;
        
        // ID列
        wchar_t buf[32];
        _itow_s(allData[i].id, buf, 10);
        lvi.pszText = buf;
        ListView_InsertItem(hwndList, &lvi);
        
        // 其他列使用改进的字符串转换
        std::wstring wname = StringToWString(allData[i].name);
        std::wstring wgender = StringToWString(allData[i].gender);
        std::wstring wbirth = StringToWString(allData[i].birth_date);
        std::wstring wdeath = StringToWString(allData[i].death_date);
        std::wstring wstatus = StringToWString(allData[i].status);
        
        // 设置各列文本
        ListView_SetItemText(hwndList, i - startIndex, 1, (LPWSTR)wname.c_str());
        ListView_SetItemText(hwndList, i - startIndex, 2, (LPWSTR)wgender.c_str());
        
        _itow_s(allData[i].virtue, buf, 10);
        ListView_SetItemText(hwndList, i - startIndex, 3, buf);
        
        ListView_SetItemText(hwndList, i - startIndex, 4, (LPWSTR)wbirth.c_str());
        ListView_SetItemText(hwndList, i - startIndex, 5, (LPWSTR)wdeath.c_str());
        ListView_SetItemText(hwndList, i - startIndex, 6, (LPWSTR)wstatus.c_str());
    }
}

void UpdatePageControls(HWND hwnd) {
    // 更新分页信息显示
    UpdatePageInfo(hwnd);
    
    // 更新按钮状态
    EnableWindow(GetDlgItem(hwnd, BTN_PREV), pageInfo.currentPage > 1);
    EnableWindow(GetDlgItem(hwnd, BTN_NEXT), pageInfo.currentPage < pageInfo.totalPages);
}

void CreateAddEditWindow(HWND hParent, Person* pPerson) {
    // 注册添加/编辑窗口类
    const wchar_t ADD_EDIT_CLASS[] = L"AddEditWindowClass";
    WNDCLASS wc = {};
    wc.lpfnWndProc = AddEditWindowProc;
    wc.hInstance = g_hInstance;
    wc.lpszClassName = ADD_EDIT_CLASS;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    
    RegisterClass(&wc);
    
    // 创建窗口
    HWND hwnd = CreateWindowEx(
        WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
        ADD_EDIT_CLASS,
        pPerson ? L"修改人员信息" : L"添加人员信息",
        WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 450, 400,
        hParent, NULL, g_hInstance, pPerson
    );
    
    if (!hwnd) {
        MessageBox(hParent, L"创建窗口失败！", L"错误", MB_ICONERROR);
        return;
    }
    
    // 居中显示窗口
    RECT rcParent, rcWindow;
    GetWindowRect(hParent, &rcParent);
    GetWindowRect(hwnd, &rcWindow);
    int x = (rcParent.left + rcParent.right) / 2 - (rcWindow.right - rcWindow.left) / 2;
    int y = (rcParent.top + rcParent.bottom) / 2 - (rcWindow.bottom - rcWindow.top) / 2;
    SetWindowPos(hwnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);
    
    // 消息循环
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (!IsWindow(hwnd)) break;
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

LRESULT CALLBACK AddEditWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static HWND hEditName, hComboGender, hEditVirtue, hEditBirth, hRadioAlive, hRadioDead, hEditDeath;
    static HWND hBtnOk, hBtnCancel;
    static Person* pPerson;
    
    switch (uMsg) {
    case WM_CREATE: {
        CREATESTRUCT* pcs = (CREATESTRUCT*)lParam;
        pPerson = (Person*)pcs->lpCreateParams;
        
        // 创建控件
        CreateWindowW(L"STATIC", L"姓名:", WS_CHILD | WS_VISIBLE, 30, 30, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hEditName = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 30, 280, 25, hwnd, (HMENU)IDC_EDIT_NAME, g_hInstance, NULL);

        CreateWindowW(L"STATIC", L"性别:", WS_CHILD | WS_VISIBLE, 30, 70, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hComboGender = CreateWindowW(L"COMBOBOX", L"", WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST, 120, 70, 280, 100, hwnd, (HMENU)IDC_COMBO_GENDER, g_hInstance, NULL);
        SendMessage(hComboGender, CB_ADDSTRING, 0, (LPARAM)L"男");
        SendMessage(hComboGender, CB_ADDSTRING, 0, (LPARAM)L"女");

        CreateWindowW(L"STATIC", L"功德:", WS_CHILD | WS_VISIBLE, 30, 110, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hEditVirtue = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 110, 280, 25, hwnd, (HMENU)IDC_EDIT_VIRTUE, g_hInstance, NULL);

        CreateWindowW(L"STATIC", L"出生日期:", WS_CHILD | WS_VISIBLE, 30, 150, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hEditBirth = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 150, 280, 25, hwnd, (HMENU)IDC_EDIT_BIRTH, g_hInstance, NULL);

        CreateWindowW(L"STATIC", L"状态:", WS_CHILD | WS_VISIBLE, 30, 190, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hRadioAlive = CreateWindowW(L"BUTTON", L"在世", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 120, 190, 80, 25, hwnd, (HMENU)IDC_RADIO_ALIVE, g_hInstance, NULL);
        hRadioDead = CreateWindowW(L"BUTTON", L"已故", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 220, 190, 80, 25, hwnd, (HMENU)IDC_RADIO_DEAD, g_hInstance, NULL);

        CreateWindowW(L"STATIC", L"死亡日期:", WS_CHILD | WS_VISIBLE, 30, 230, 80, 25, hwnd, NULL, g_hInstance, NULL);
        hEditDeath = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 230, 280, 25, hwnd, (HMENU)IDC_EDIT_DEATH, g_hInstance, NULL);

        hBtnOk = CreateWindowW(L"BUTTON", L"确定", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 200, 300, 80, 35, hwnd, (HMENU)IDC_BTN_OK, g_hInstance, NULL);
        hBtnCancel = CreateWindowW(L"BUTTON", L"取消", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 300, 300, 80, 35, hwnd, (HMENU)IDC_BTN_CANCEL, g_hInstance, NULL);

        // 设置默认值
        SendMessage(hComboGender, CB_SETCURSEL, 0, 0);
        SendMessage(hRadioAlive, BM_SETCHECK, BST_CHECKED, 0);
        EnableWindow(hEditDeath, FALSE);

        // 如果是修改模式，填充现有数据
        if (pPerson) {
            SetWindowTextW(hEditName, StringToWString(pPerson->name).c_str());
            if (pPerson->gender == "男") SendMessage(hComboGender, CB_SETCURSEL, 0, 0);
            else if (pPerson->gender == "女") SendMessage(hComboGender, CB_SETCURSEL, 1, 0);
            
            wchar_t buf[32];
            _itow_s(pPerson->virtue, buf, 10);
            SetWindowTextW(hEditVirtue, buf);
            SetWindowTextW(hEditBirth, StringToWString(pPerson->birth_date).c_str());
            
            if (pPerson->status == "在世") {
                SendMessage(hRadioAlive, BM_SETCHECK, BST_CHECKED, 0);
                EnableWindow(hEditDeath, FALSE);
            } else {
                SendMessage(hRadioDead, BM_SETCHECK, BST_CHECKED, 0);
                SetWindowTextW(hEditDeath, StringToWString(pPerson->death_date).c_str());
            }
        }

        SetFocus(hEditName);
        return 0;
    }
    
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_RADIO_ALIVE:
            EnableWindow(hEditDeath, FALSE);
            SetWindowTextW(hEditDeath, L"");
            break;
        case IDC_RADIO_DEAD:
            EnableWindow(hEditDeath, TRUE);
            break;
        case IDC_BTN_OK: {
            try {
                // 收集数据
                wchar_t name[256], birth[256], death[256], virtue[32];
                GetWindowTextW(hEditName, name, 256);
                GetWindowTextW(hEditBirth, birth, 256);
                GetWindowTextW(hEditDeath, death, 256);
                GetWindowTextW(hEditVirtue, virtue, 32);
                
                // 获取性别
                int genderIndex = SendMessage(hComboGender, CB_GETCURSEL, 0, 0);
                const wchar_t* gender = (genderIndex == 0) ? L"男" : L"女";
                
                // 获取状态
                bool isAlive = (SendMessage(hRadioAlive, BM_GETCHECK, 0, 0) == BST_CHECKED);
                const wchar_t* status = isAlive ? L"在世" : L"已故";
                
                // 验证数据
                if (wcslen(name) == 0 || wcslen(birth) == 0 || wcslen(virtue) == 0) {
                    MessageBox(hwnd, L"请填写完整信息！", L"提示", MB_ICONWARNING);
                    return 0;
                }
                
                // 创建Person对象
                Person p;
                p.name = WStringToString(name);
                p.gender = WStringToString(gender);
                p.virtue = _wtoi(virtue);
                p.birth_date = WStringToString(birth);
                p.death_date = WStringToString(death);
                p.status = WStringToString(status);
                
                if (pPerson) {
                    // 修改模式：更新死亡信息
                    if (!isAlive && wcslen(death) > 0) {
                        db.updateDeathInfo(pPerson->id, p.death_date);
                    }
                } else {
                    // 添加模式
                    db.addPerson(p);
                }
                
                // 刷新主窗口数据
                HWND hMainWnd = GetParent(hwnd);
                if (hMainWnd) {
                    HWND hList = GetDlgItem(hMainWnd, IDC_LIST);
                    if (hList) {
                        RefreshList(hList);
                    }
                }
                
                DestroyWindow(hwnd);
            } catch (const std::exception& e) {
                std::string errorMsg = "保存数据异常: " + std::string(e.what());
                std::wstring werrorMsg(errorMsg.begin(), errorMsg.end());
                MessageBox(hwnd, werrorMsg.c_str(), L"异常错误", MB_ICONERROR);
            }
            break;
        }
        case IDC_BTN_CANCEL:
            DestroyWindow(hwnd);
            break;
        }
        break;
        
    case WM_CLOSE:
        DestroyWindow(hwnd);
        break;
        
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
