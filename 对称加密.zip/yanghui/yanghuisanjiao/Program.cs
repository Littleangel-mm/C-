﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("请输入要打印的行数：");

        if (!int.TryParse(Console.ReadLine(), out int rows) || rows <= 0)
        {
            Console.WriteLine("输入无效，请输入一个正整数！");
            return;
        }

        int[][] triangle = new int[rows][];

        for (int i = 0; i < rows; i++)
        {
            triangle[i] = new int[i + 1];
            triangle[i][0] = 1;
            triangle[i][i] = 1;

            for (int j = 1; j < i; j++)
            {
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
            }
        }

        Console.WriteLine("\n生成的杨辉三角：\n");

        for (int i = 0; i < rows; i++)
        {
            // 打印空格让三角居中
            Console.Write(new string(' ', (rows - i) * 2));

            for (int j = 0; j <= i; j++)
            {
                Console.Write($"{triangle[i][j],4}"); // 格式控制输出
            }
            Console.WriteLine();
        }

        Console.WriteLine("\n按任意键退出...");
        Console.ReadKey();
    }
}
