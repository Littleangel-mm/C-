﻿using System;

namespace CaesarCipherConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" 凯撒加密器");

            Console.Write("请输入明文或密文：");
            string input = Console.ReadLine();

            Console.Write("请输入偏移量（正数加密，负数解密）：");
            int shift;
            while (!int.TryParse(Console.ReadLine(), out shift))
            {
                Console.Write("请输入有效的整数偏移量：");
            }

            string result = CaesarCipher(input, shift);

            Console.WriteLine("\n结果： " + result);
            Console.WriteLine("\n按任意键退出...");
            Console.ReadKey();
        }

        static string CaesarCipher(string text, int shift)
        {
            char[] buffer = text.ToCharArray();

            for (int i = 0; i < buffer.Length; i++)
            {
                char c = buffer[i];

                if (char.IsLetter(c))
                {
                    char baseChar = char.IsUpper(c) ? 'A' : 'a';
                    buffer[i] = (char)((((c - baseChar + shift) + 26) % 26) + baseChar);
                }
                // 非字母字符保持不变
            }

            return new string(buffer);
        }
    }
}
