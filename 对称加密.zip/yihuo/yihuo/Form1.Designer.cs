﻿namespace XORFileEncryptorGUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label labelFile;
        private System.Windows.Forms.TextBox textBoxFilePath;
        private System.Windows.Forms.Button buttonBrowse;
        private System.Windows.Forms.Label labelKey;
        private System.Windows.Forms.TextBox textBoxKey;
        private System.Windows.Forms.Button buttonEncrypt;
        private System.Windows.Forms.Button buttonDecrypt;
        private System.Windows.Forms.Label labelStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelFile = new System.Windows.Forms.Label();
            this.textBoxFilePath = new System.Windows.Forms.TextBox();
            this.buttonBrowse = new System.Windows.Forms.Button();
            this.labelKey = new System.Windows.Forms.Label();
            this.textBoxKey = new System.Windows.Forms.TextBox();
            this.buttonEncrypt = new System.Windows.Forms.Button();
            this.buttonDecrypt = new System.Windows.Forms.Button();
            this.labelStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // labelFile
            this.labelFile.AutoSize = true;
            this.labelFile.Location = new System.Drawing.Point(12, 15);
            this.labelFile.Text = "文件路径：";

            // textBoxFilePath
            this.textBoxFilePath.Location = new System.Drawing.Point(80, 12);
            this.textBoxFilePath.Size = new System.Drawing.Size(300, 20);

            // buttonBrowse
            this.buttonBrowse.Location = new System.Drawing.Point(390, 10);
            this.buttonBrowse.Size = new System.Drawing.Size(75, 23);
            this.buttonBrowse.Text = "浏览...";
            this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);

            // labelKey
            this.labelKey.AutoSize = true;
            this.labelKey.Location = new System.Drawing.Point(12, 50);
            this.labelKey.Text = "密钥：";

            // textBoxKey
            this.textBoxKey.Location = new System.Drawing.Point(80, 47);
            this.textBoxKey.Size = new System.Drawing.Size(300, 20);

            // buttonEncrypt
            this.buttonEncrypt.Location = new System.Drawing.Point(80, 80);
            this.buttonEncrypt.Size = new System.Drawing.Size(100, 30);
            this.buttonEncrypt.Text = "加密";
            this.buttonEncrypt.Click += new System.EventHandler(this.buttonEncrypt_Click);

            // buttonDecrypt
            this.buttonDecrypt.Location = new System.Drawing.Point(190, 80);
            this.buttonDecrypt.Size = new System.Drawing.Size(100, 30);
            this.buttonDecrypt.Text = "解密";
            this.buttonDecrypt.Click += new System.EventHandler(this.buttonDecrypt_Click);

            // labelStatus
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new System.Drawing.Point(12, 125);
            this.labelStatus.Size = new System.Drawing.Size(0, 13);

            // Form1
            this.ClientSize = new System.Drawing.Size(484, 161);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Controls.Add(this.labelFile);
            this.Controls.Add(this.textBoxFilePath);
            this.Controls.Add(this.buttonBrowse);
            this.Controls.Add(this.labelKey);
            this.Controls.Add(this.textBoxKey);
            this.Controls.Add(this.buttonEncrypt);
            this.Controls.Add(this.buttonDecrypt);
            this.Controls.Add(this.labelStatus);
            this.Name = "Form1";
            this.Text = "异或加密器";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
