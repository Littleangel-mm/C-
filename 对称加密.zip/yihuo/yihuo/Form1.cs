using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace XORFileEncryptorGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBoxFilePath.Text = ofd.FileName;
            }
        }

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            ProcessFile(encrypt: true);
        }

        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            ProcessFile(encrypt: false);
        }

        private void ProcessFile(bool encrypt)
        {
            string filePath = textBoxFilePath.Text;
            string key = textBoxKey.Text;

            if (!File.Exists(filePath))
            {
                MessageBox.Show("��ѡ����ȷ���ļ���");
                return;
            }

            if (string.IsNullOrEmpty(key))
            {
                MessageBox.Show("��Կ����Ϊ�գ�");
                return;
            }

            try
            {
                byte[] fileBytes = File.ReadAllBytes(filePath);
                byte[] keyBytes = Encoding.UTF8.GetBytes(key);
                byte[] result = new byte[fileBytes.Length];

                for (int i = 0; i < fileBytes.Length; i++)
                {
                    result[i] = (byte)(fileBytes[i] ^ keyBytes[i % keyBytes.Length]);
                }

                string outputPath = encrypt
                    ? filePath + ".xor"
                    : filePath + ".decrypted";

                File.WriteAllBytes(outputPath, result);
                labelStatus.Text = (encrypt ? "������ɣ�" : "������ɣ�") + $" ����ļ���{outputPath}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("��������" + ex.Message);
            }
        }
    }
}
